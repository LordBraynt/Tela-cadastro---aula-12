const botao = document.getElementById('botaoInterruptor');
const lampada = document.getElementById('lampada');
const statusTexto = document.getElementById('status');

let lampadaAcesa = false;

botao.addEventListener('click', function () {
    if (lampadaAcesa === false) {
        lampada.classList.remove('apagada');
        lampada.classList.add('acesa');
        document.body.classList.remove('apagado');
        document.body.classList.add('aceso');
        
        statusTexto.textContent = 'A lâmpada está acesa!';
        botao.textContent = 'Apagar';
        lampadaAcesa = true;
    } else {
        lampada.classList.remove('acesa');
        lampada.classList.add('apagada');
        document.body.classList.remove('aceso');
        document.body.classList.add('apagado');
        
        statusTexto.textContent = 'A lâmpada está apagada.';
        botao.textContent = 'Acender';
        lampadaAcesa = false;
    }
});
